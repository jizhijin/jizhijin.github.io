window.addEventListener('DOMContentLoaded', function () {

    const searchForm = document.getElementById('searchForm');
    const keywordInput = document.getElementById('keyword');
    const distanceInput = document.getElementById('distance');
    const categorySelect = document.getElementById('category');
    const autoDetect = document.getElementById('autoDetect');
    const locationInput = document.getElementById('location');
    const resultsDiv = document.getElementById('results');
    const detailsDiv = document.getElementById('event-details');
    let currentResults = [];

    autoDetect.addEventListener('change', function () {
        locationInput.style.display = this.checked ? 'none' : 'block';
        locationInput.setCustomValidity('');
    });

    document.getElementById('searchBtn').addEventListener('click', function () {
        keywordInput.setCustomValidity('');
        locationInput.setCustomValidity('');

        let valid = true;
        if (!keywordInput.value.trim()) {
            keywordInput.setCustomValidity('Keyword is required');
            keywordInput.reportValidity();
            valid = false;
        }
        if (!autoDetect.checked && !locationInput.value.trim()) {
            locationInput.setCustomValidity('Location is required');
            locationInput.reportValidity();
            valid = false;
        }
        if (!valid) return;
        searchForm.dispatchEvent(new Event('submit'));
    });

    document.getElementById('clearBtn').addEventListener('click', function () {
        searchForm.reset();
        locationInput.style.display = 'block';
        keywordInput.setCustomValidity('');
        locationInput.setCustomValidity('');
        resultsDiv.innerHTML = '';
        detailsDiv.innerHTML = '';
        currentResults = [];
    });

    searchForm.addEventListener('submit', function (e) {
        e.preventDefault();
        performSearch();
    });

    function performSearch() {
        const keyword = keywordInput.value.trim();
        const distance = distanceInput.value.trim() || '10';
        const category = categorySelect.value;
        const useAuto = autoDetect.checked;
        const locationVal = locationInput.value.trim();

        if (useAuto) {
            fetch(`https://ipinfo.io/json?token=e97d7685164ce5`)
                .then(res => res.json())
                .then(data => {
                    const loc = data.loc.split(',');
                    fetchEvents(keyword, distance, category, loc[0], loc[1]);
                });
        } else {
            fetch(`/geocode?address=${encodeURIComponent(locationVal)}`)
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'OK') {
                        const loc = data.location;
                        fetchEvents(keyword, distance, category, loc.lat, loc.lng);
                    } else {
                        locationInput.setCustomValidity('Invalid location');
                        locationInput.reportValidity();
                    }
                })
                .catch(err => {
                    locationInput.setCustomValidity('Error fetching location');
                    locationInput.reportValidity();
                });
        }
    }

    function fetchEvents(keyword, distance, category, lat, lng) {
        const params = new URLSearchParams({keyword, distance, category, lat, lng});
        fetch(`/api/search?${params.toString()}`)
            .then(res => res.json())
            .then(data => {
                if (data.error) {
                    resultsDiv.innerHTML = `<p>${data.error}</p>`;
                    detailsDiv.innerHTML = '';
                    currentResults = [];
                } else {
                    currentResults = data._embedded?.events || [];
                    renderResults(currentResults);
                    detailsDiv.innerHTML = '';
                }
            })
            .catch(err => {
                resultsDiv.innerHTML = `<p>${err}</p>`;
                detailsDiv.innerHTML = '';
                currentResults = [];
            });
    }

    function renderResults(events) {
        resultsDiv.innerHTML = '';
        if (events.length === 0) {
            resultsDiv.innerHTML = '<p>No records found</p>';
            return;
        }

        let html = `<table id="results-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Icon</th>
                    <th class="sortable" data-key="name">Event</th>
                    <th class="sortable" data-key="genre">Genre</th>
                    <th class="sortable" data-key="venue">Venue</th>
                </tr>
            </thead>
            <tbody>`;

        events.forEach(ev => {
            const dateTime = ev.dates?.start?.dateTime || (ev.dates?.start?.localDate + 'T00:00:00');
            const formattedDate = dateTime ? new Date(dateTime).toLocaleString('en-GB', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            }).replace(/-/g, '/').replace(',', '') : '';

            let genreText = '';
            if (ev.classifications && ev.classifications.length > 0) {
                genreText = ev.classifications[0].genre?.name || ev.classifications[0].segment?.name || '';
            }

            const venue = (ev._embedded?.venues && ev._embedded.venues.length > 0)
                ? ev._embedded.venues[0].name : '';
            const imgUrl = (ev.images && ev.images.length > 0) ? ev.images[0].url : '';

            html += `<tr>
                <td>${formattedDate}</td>
                <td><img src='${imgUrl}' alt='icon' width='50'/></td>
                <td><a href="#" class="event-link" data-id="${ev.id}">${ev.name || ''}</a></td>
                <td>${genreText || 'N/A'}</td>
                <td>${venue}</td>
            </tr>`;
        });

        html += '</tbody></table>';
        resultsDiv.innerHTML = html;

        document.querySelectorAll('.event-link').forEach(link => {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                fetchEventDetails(this.dataset.id);
            });
        });

        document.querySelectorAll('.sortable').forEach(th => {
            th.addEventListener('click', () => sortTable(th.dataset.key));
        });
    }

    function sortTable(key) {
        const table = document.getElementById('results-table');
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.rows);
        let asc = table.dataset.sortKey !== key || table.dataset.sortOrder === 'desc';
        table.dataset.sortKey = key;
        table.dataset.sortOrder = asc ? 'asc' : 'desc';
        rows.sort((a, b) => {
            let aVal, bVal;
            if (key === 'name') aVal = a.cells[2].textContent.trim().toLowerCase();
            if (key === 'genre') aVal = a.cells[3].textContent.trim().toLowerCase();
            if (key === 'venue') aVal = a.cells[4].textContent.trim().toLowerCase();
            return asc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        });
        tbody.innerHTML = '';
        rows.forEach(r => tbody.appendChild(r));
    }

    function fetchEventDetails(id) {
        fetch(`/api/event/${id}`)
            .then(res => res.json())
            .then(ev => {
                if (ev.error) alert(ev.error);
                else renderEventCard(ev);
            })
            .catch(err => alert(err));
    }

    function renderEventCard(ev) {
        const seatmapUrl = ev.seatmap?.staticUrl || '/images/venue-map-placeholder.png';

        const eventDate = ev.dates?.start?.dateTime || ev.dates?.start?.localDate;
        const formattedDate = eventDate ? new Date(eventDate).toLocaleString('en-GB', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        }).replace(/-/g, '/').replace(',', '') : '';

        const ticketStatusColor = {
            'onsale': 'green',
            'offsale': 'red',
            'canceled': 'black',
            'postponed': 'orange',
            'rescheduled': 'orange'
        };
        const statusCode = ev.dates?.status?.code || '';
        const statusColor = ticketStatusColor[statusCode.toLowerCase()] || 'black';
        const statusTag = statusCode.charAt(0).toUpperCase() + statusCode.slice(1);

        const artistHtml = (ev._embedded?.attractions || [])
            .map(a => a.name && a.url ? `<a href="${a.url}" target="_blank">${a.name}</a>` : a.name || '')
            .filter(Boolean)
            .join(' | ') || 'N/A';

        let genresText = '';
        if (ev.classifications && ev.classifications.length > 0) {
            genresText = ev.classifications[0].genre?.name || ev.classifications[0].segment?.name || '';
        }

        const eventHtml = `
<div class="details-container event-card" 
    style="margin:20px auto; max-width:900px; background: rgba(255, 255, 255, 0.8); border-radius:10px; padding:15px;">
    <h2 style="margin-bottom:10px;">${ev.name || ''}</h2>
    <div style="display:flex; gap:15px; align-items:flex-start;">
        <div style="flex:1; display:flex; flex-direction:column; gap:5px;">
            <p><strong>Date:</strong><br>${formattedDate}</p>
            <p><strong>Artist/Team:</strong><br>${artistHtml}</p>
            <p><strong>Genres:</strong><br>${genresText || 'N/A'}</p>
            <p><strong>Ticket Status:</strong><br>
                <span style="
                    display:inline-block;
                    padding:2px 8px;
                    border-radius:5px;
                    background:${statusColor};
                    color:#fff;
                    font-size:0.85em;
                    font-weight:bold;
                ">${statusTag}</span>
            </p>
            <p class="ticket-link">Buy Ticket At:<br><a href="${ev.url || '#'}" target="_blank">Ticketmaster</a></p>
        </div>
        <div style="flex-shrink:0; display:flex; align-items:center; justify-content:center;">
            <img src="${seatmapUrl}" alt="Venue Map" style="max-height:400px; max-width:400px; object-fit:contain;">
        </div>
    </div>
</div>
`;

        const showVenueHtml = `
            <div style="text-align:center; margin-top:10px;font-size: 26px;color: white;">
                <a href="#" id="showVenueDetails" style="text-decoration:underline; cursor:pointer;color: white">Show Venue Details</a>
            </div>
            `;

        detailsDiv.innerHTML = eventHtml + showVenueHtml;
        detailsDiv.scrollIntoView({behavior: 'smooth', block: 'center'});

        document.getElementById('showVenueDetails').addEventListener('click', function (e) {
            e.preventDefault();

            const venue = ev._embedded?.venues?.[0] || {};
            const venueLogo = (venue.images && venue.images.length > 0) ? `<img src="${venue.images[0].url}" alt="Venue Logo" style="max-height:80px; object-fit:contain;">` : '';
            const venueFull = `${venue.name || ''}, ${venue.address?.line1 || ''}, ${venue.city?.name || ''}, ${venue.state?.stateCode || ''} ${venue.postalCode || ''}`;
            const googleMapLink = venue.location ? `<a href="https://www.google.com/maps/search/?api=1&query=${venue.location.latitude},${venue.location.longitude}" target="_blank">Open in Google Maps</a>` : '';

            const venueHtml = `
    <div class="venue-footer" style="margin-top:20px; max-width:900px; background:#fff; border-radius:8px; padding:15px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">
        <div style="text-align:center;">
            <strong>${venue.name || ''}</strong><br>
            ${venueLogo}
        </div>
        <div style="display:flex; justify-content:center; align-items:center; margin-top:10px;">
            <div style="flex:1; text-align:right; padding-right:10px;">
                ${venueFull}<br>${googleMapLink}
            </div>
            <div style="width:1px; background:#000; align-self:stretch; margin:0 10px;"></div>
            <div style="flex:1; text-align:left; padding-left:10px;">
                <a href="#" id="moreVenueEvents" style="text-decoration:underline; cursor:pointer;">More events at this venue</a>
            </div>
        </div>
        <div id="venueEventsContainer" style="margin-top:10px; display:none;"></div>
    </div>
    `;

            detailsDiv.insertAdjacentHTML('beforeend', venueHtml);
            this.style.display = 'none';

            document.getElementById('moreVenueEvents').addEventListener('click', function (e) {
                e.preventDefault();
                const container = document.getElementById('venueEventsContainer');
                container.style.display = 'block';
                this.style.display = 'none';

                fetch(`/api/venue_by_keyword?keyword=${encodeURIComponent(venue.name)}`)
                    .then(res => res.json())
                    .then(v => {
                        const events = v._embedded?.events || [];
                        if (events.length === 0) container.innerHTML = '<p>No events found</p>';
                        else {
                            let html = '<ul style="text-align:left;">';
                            events.forEach(ev => {
                                html += `<li><a href="#" target="_blank">${ev.name} (${ev.dates?.start?.localDate || ''})</a></li>`;
                            });
                            html += '</ul>';
                            container.innerHTML = html;
                        }
                    })
                    .catch(err => container.innerHTML = `<p>${err}</p>`);
            });
        });


    }


});
